import { useState } from 'react';

export default function Booking(){
  const [form, setForm] = useState({ name:'', email:'', phone:'', date:'', time:'', guests:2, notes:'' });
  const [msg, setMsg] = useState('');

  const onChange = e => setForm({...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setMsg('Submitting...');
    try {
      const res = await fetch(import.meta.env.VITE_API_URL + '/api/bookings', {
        method:'POST',
        headers:{ 'Content-Type':'application/json' },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if(res.ok){
        setMsg('Booking request submitted! We will confirm soon.');
        setForm({ name:'', email:'', phone:'', date:'', time:'', guests:2, notes:'' });
      } else {
        setMsg(data.message || 'Error submitting');
      }
    } catch (err) {
      setMsg('Network error');
    }
  }

  return (
    <div className="max-w-2xl mx-auto card">
      <h2 className="text-2xl font-semibold mb-4">Reserve a table</h2>
      <form onSubmit={submit} className="space-y-3">
        <input required name="name" value={form.name} onChange={onChange} placeholder="Your name" className="w-full p-3 border rounded" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <input name="email" value={form.email} onChange={onChange} placeholder="Email (optional)" className="w-full p-3 border rounded" />
          <input name="phone" value={form.phone} onChange={onChange} placeholder="Phone (optional)" className="w-full p-3 border rounded" />
        </div>
        <div className="flex gap-3">
          <input required name="date" type="date" value={form.date} onChange={onChange} className="p-3 border rounded flex-1" />
          <input required name="time" type="time" value={form.time} onChange={onChange} className="p-3 border rounded w-36" />
        </div>
        <input required name="guests" type="number" min="1" value={form.guests} onChange={onChange} className="w-28 p-3 border rounded" />
        <textarea name="notes" value={form.notes} onChange={onChange} placeholder="Notes (e.g., dietary req.)" className="w-full p-3 border rounded" />
        <div className="flex items-center justify-between">
          <button type="submit" className="px-5 py-2 bg-amber-600 text-white rounded-full">Request Booking</button>
          <div className="text-sm text-gray-600">{msg}</div>
        </div>
      </form>
    </div>
  );
}
