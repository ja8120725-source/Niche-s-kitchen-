export default function Home(){
  return (
    <div className="space-y-8">
      <header className="rounded-3xl overflow-hidden hero relative">
        <div className="bg-[url('https://images.unsplash.com/photo-1551782450-a2132b4ba21d?auto=format&fit=crop&w=1400&q=80')] bg-cover bg-center h-64 flex items-center">
          <div className="max-w-4xl mx-auto p-6 text-white">
            <h1 className="text-4xl md:text-5xl font-bold drop-shadow-lg">Niche's Kitchen</h1>
            <p className="mt-2 text-lg drop-shadow">Handcrafted seasonal dishes • Warm service • Book your table online</p>
            <a href="/book" className="inline-block mt-4 px-5 py-2 bg-amber-600 rounded-full text-white font-semibold shadow">Reserve a Table</a>
          </div>
        </div>
      </header>

      <section className="grid md:grid-cols-3 gap-6">
        <div className="card">
          <h3 className="text-xl font-semibold">Our Menu</h3>
          <p className="mt-2 text-sm text-gray-700">Seasonal, local, and delicious. View chef specials and signature dishes.</p>
        </div>
        <div className="card">
          <h3 className="text-xl font-semibold">Private Events</h3>
          <p className="mt-2 text-sm text-gray-700">Book our space for birthdays, intimate dinners, and corporate events.</p>
        </div>
        <div className="card">
          <h3 className="text-xl font-semibold">Opening Hours</h3>
          <p className="mt-2 text-sm text-gray-700">Mon–Sun: 11:00 — 22:00</p>
        </div>
      </section>

      <section className="mt-6 card">
        <h2 className="text-2xl font-bold">Why choose Niche's Kitchen?</h2>
        <p className="mt-2 text-gray-700">We craft memorable meals with seasonal produce and a cozy, welcoming atmosphere. Book now and enjoy a curated dining experience.</p>
      </section>
    </div>
  );
}
