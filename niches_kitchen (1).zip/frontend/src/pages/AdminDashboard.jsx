import { useEffect, useState } from 'react';
import BookingCard from '../components/BookingCard';
import { useNavigate } from 'react-router-dom';

export default function AdminDashboard(){
  const [bookings, setBookings] = useState([]);
  const [msg, setMsg] = useState('');
  const nav = useNavigate();

  const token = localStorage.getItem('niches_token');

  useEffect(() => {
    if (!token) { nav('/admin/login'); return; }
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const res = await fetch(import.meta.env.VITE_API_URL + '/api/bookings', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.status === 401) { localStorage.removeItem('niches_token'); nav('/admin/login'); return; }
      const data = await res.json();
      setBookings(data);
    } catch {
      setMsg('Network error');
    }
  };

  const updateBooking = async (id, status) => {
    try {
      await fetch(import.meta.env.VITE_API_URL + '/api/bookings/' + id, {
        method: 'PUT',
        headers: { 'Content-Type':'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ status })
      });
      fetchBookings();
    } catch {
      setMsg('Network error');
    }
  };

  const deleteBooking = async (id) => {
    if(!confirm('Delete this booking?')) return;
    try {
      await fetch(import.meta.env.VITE_API_URL + '/api/bookings/' + id, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchBookings();
    } catch {
      setMsg('Network error');
    }
  };

  const logout = () => { localStorage.removeItem('niches_token'); nav('/admin/login'); };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-semibold">Bookings Dashboard</h2>
        <div>
          <button onClick={logout} className="px-3 py-1 bg-gray-200 rounded">Logout</button>
        </div>
      </div>

      <div className="space-y-3">
        {msg && <div className="text-sm text-red-600">{msg}</div>}
        {bookings.length === 0 && <div className="text-gray-600">No bookings found</div>}
        <div className="grid gap-3">
          {bookings.map(b => (
            <BookingCard key={b._id} booking={b} onUpdate={updateBooking} onDelete={deleteBooking} />
          ))}
        </div>
      </div>
    </div>
  );
}
