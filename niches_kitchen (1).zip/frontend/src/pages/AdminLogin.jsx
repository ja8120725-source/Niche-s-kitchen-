import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function AdminLogin(){
  const [form, setForm] = useState({ email:'', password:'' });
  const [msg, setMsg] = useState('');
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setMsg('Signing in...');
    try {
      const res = await fetch(import.meta.env.VITE_API_URL + '/api/admin/login', {
        method:'POST',
        headers:{ 'Content-Type':'application/json' },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if(res.ok){
        localStorage.setItem('niches_token', data.token);
        nav('/admin/dashboard');
      } else setMsg(data.message || 'Login failed');
    } catch {
      setMsg('Network error');
    }
  };

  return (
    <div className="max-w-md mx-auto card">
      <h2 className="text-xl font-semibold mb-4">Admin Sign in</h2>
      <form onSubmit={submit} className="space-y-3">
        <input required value={form.email} onChange={e => setForm({...form, email:e.target.value})} placeholder="Email" className="w-full p-3 border rounded" />
        <input required type="password" value={form.password} onChange={e => setForm({...form, password:e.target.value})} placeholder="Password" className="w-full p-3 border rounded" />
        <div className="flex items-center justify-between">
          <button className="px-4 py-2 bg-amber-600 text-white rounded-full">Sign in</button>
          <div className="text-sm text-gray-600">{msg}</div>
        </div>
      </form>
    </div>
  );
}
