import { Outlet, Link } from 'react-router-dom';

export default function App(){
  return (
    <div>
      <nav className="bg-white/80 backdrop-blur sticky top-0 z-50 shadow p-4 flex justify-between items-center max-w-6xl mx-auto rounded-b-xl mt-4">
        <div className="text-2xl font-extrabold text-amber-700">Niche's Kitchen</div>
        <div className="space-x-4">
          <Link to="/" className="hover:underline">Home</Link>
          <Link to="/book" className="hover:underline">Book a Table</Link>
          <Link to="/admin/login" className="hover:underline">Admin</Link>
        </div>
      </nav>
      <main className="p-6 max-w-6xl mx-auto mt-6">
        <Outlet />
      </main>
      <footer className="text-center p-4 text-sm text-gray-500">© {new Date().getFullYear()} Niche's Kitchen</footer>
    </div>
  );
}
