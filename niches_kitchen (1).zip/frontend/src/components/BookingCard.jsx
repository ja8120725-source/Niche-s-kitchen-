export default function BookingCard({ booking, onUpdate, onDelete }){
  return (
    <div className="p-4 border rounded-xl bg-white">
      <div className="flex justify-between items-start">
        <div>
          <div className="font-semibold">{booking.name} <span className="text-sm text-gray-500">({booking.guests})</span></div>
          <div className="text-sm text-gray-600">{booking.date} • {booking.time}</div>
          <div className="text-sm">{booking.email}{booking.phone ? ' • ' + booking.phone : ''}</div>
        </div>
        <div className="text-sm">
          <span className={booking.status === 'accepted' ? 'px-2 py-1 rounded bg-green-100 text-green-700' : booking.status === 'declined' ? 'px-2 py-1 rounded bg-red-100 text-red-700' : 'px-2 py-1 rounded bg-yellow-100 text-yellow-700'}>{booking.status}</span>
        </div>
      </div>
      <p className="mt-2 text-gray-700">{booking.notes}</p>
      <div className="mt-3 flex gap-2">
        <button onClick={() => onUpdate(booking._id, 'accepted')} className="px-3 py-1 bg-green-600 text-white rounded">Accept</button>
        <button onClick={() => onUpdate(booking._id, 'declined')} className="px-3 py-1 bg-red-600 text-white rounded">Decline</button>
        <button onClick={() => onDelete(booking._id)} className="px-3 py-1 bg-gray-200 rounded">Delete</button>
      </div>
    </div>
  );
}
