const express = require('express');
const router = express.Router();
const bookingController = require('../controllers/bookingController');
const adminController = require('../controllers/adminController');

router.post('/bookings', bookingController.createBooking);
router.get('/bookings', adminController.protect, bookingController.getAllBookings);
router.put('/bookings/:id', adminController.protect, bookingController.updateBooking);
router.delete('/bookings/:id', adminController.protect, bookingController.deleteBooking);

module.exports = router;
