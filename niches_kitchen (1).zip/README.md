# Niche's Kitchen - Fullstack Website (React + Tailwind | Express + MongoDB)

This package contains a complete full-stack project for *Niche's Kitchen*:
- frontend: Vite + React + Tailwind (in /frontend)
- backend: Express + Mongoose (in /backend)

## Quick setup (development)

### Backend
1. cd backend
2. npm install
3. copy `.env.example` to `.env` and fill values (MONGO_URI, JWT_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD)
4. npm run dev
   - server runs on http://localhost:5000

### Frontend
1. cd frontend
2. npm install
3. create `.env` with: `VITE_API_URL=http://localhost:5000`
4. npm run dev
   - app runs on Vite dev server (e.g., http://localhost:5173)

## Deploying (recommended simple path: Render.com)

1. Create a MongoDB Atlas cluster and obtain the connection string.
2. Create a new Web Service on Render for the backend:
   - Connect your repo or upload files.
   - Set the start command: `npm start` and environment variables from `.env`.
3. For the frontend:
   - Build (`npm run build`) and serve static `dist/` via a static site host (Netlify/Vercel) or serve through Nginx.
   - Alternatively, set up another Render static site pointing to `frontend/dist`.

## Notes
- The server auto-creates an admin user from `ADMIN_EMAIL` and `ADMIN_PASSWORD` on startup if none exists.
- Change the initial admin password after first login.
- For production, lock down CORS, use HTTPS, strong JWT secret, and consider rate-limiting / captcha.

If you'd like, I can:
- generate Dockerfiles and docker-compose,
- produce a step-by-step Render or Railway deployment script,
- or deploy to Render on your behalf IF you provide temporary access (but it's safer you follow the guide or grant limited access).

Enjoy — and tell me which extra (Docker, SendGrid emails, Stripe deposits, or deploy guide) you'd like next.
